# firstProduct_VS2010
串口通讯，流程控制，拟合数据。
